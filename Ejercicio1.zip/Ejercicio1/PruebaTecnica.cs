﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class PruebaTecnica
    {
        static void Main(string[] args)
        {
            int[] myArray  = new int[5] {32,20,40,3,40};
            numeroAlto(myArray);
        }

        public static void numeroAlto(int[] numeros)
        {
            int numeroalto = 0;

            foreach (var numero in numeros)
            {
                if (numero > numeroalto)
                {
                    numeroalto = numero;
                }
            }
            
            Console.WriteLine(numeroalto);
            Console.ReadLine();
        }
    }
}
