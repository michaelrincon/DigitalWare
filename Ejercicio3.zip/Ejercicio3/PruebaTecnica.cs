﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class PruebaTecnica
    {
        static void Main(string[] args)
        {
            int[] arreglo = new int[] {1,8,6,7,2,5};
            numerosSumados(arreglo);

        }

        public static void numerosSumados(int [] numeros)
        {
            int numero1 = 0;
            int numero2= 0;
            bool encontrados = false;

            for (int i = 0; i < numeros.Length; i++)
            {
                if (encontrados)
                {
                    break;
                }
                for (int j = 0; j < numeros.Length; j++)
                {
                    if (i != j)
                    {
                        if (numeros[i] +numeros[j] == 10)
                        {
                            numero1 = numeros[i];
                            numero2 = numeros[j];
                            encontrados = true;
                            break;
                        }
                    }
                    
                }
            }

            Console.WriteLine(numero1 + " " + numero2);
            Console.ReadLine();
        }
    }
}
