﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Ejercicio5.Data;
using Ejercicio5.Models;

namespace Ejercicio5.Controllers
{
    public class PeliculasController : ApiController
    {
        private Ejercicio5Context db = new Ejercicio5Context();

        // GET: api/Peliculas
        public IEnumerable<Pelicula> GetPeliculas()
        {
            List<Pelicula> dbEjercicio = new List<Pelicula>();

            for (int i = 1; i <= 10; i++)
            {
                dbEjercicio.Add(db.Peliculas.Find(i));
            }
            return dbEjercicio;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PeliculaExists(int id)
        {
            return db.Peliculas.Count(e => e.ID == id) > 0;
        }
    }
}