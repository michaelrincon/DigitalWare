﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Ejercicio5.Models
{
    public class Pelicula
    {
        [Key]
        public int ID { get; set; }
        public string nombrePelicula { get; set; }
        public string nombreDirector { get; set; }
        public string genero { get; set; }
    }
}