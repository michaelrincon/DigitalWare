﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Ejercicio4.Models
{
    public class EstudianteModel
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string nombre { get; set; }
    }
}