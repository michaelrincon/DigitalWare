﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Ejercicio4.Models
{
    public class NotasModel
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public float nota { get; set; }
        [Required]
        public string periodo { get; set; }
        public int EstudianteId { get; set; }
        public int MateriaId { get; set; }
        [ForeignKey("MateriaId")]
        public virtual MateriaModel Materia { get; set; }
        [ForeignKey("EstudianteId")]
        public virtual EstudianteModel Estudiante { get; set; }
    }
}