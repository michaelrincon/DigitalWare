﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ejercicio4.Data;
using Ejercicio4.Models;

namespace Ejercicio4.Controllers
{
    public class EstudianteController : Controller
    {
        private Ejercicio4Context db = new Ejercicio4Context();

        // GET: Estudiante
        public ActionResult Index()
        {
            return View(db.EstudianteModels.ToList());
        }

        // GET: Estudiante/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstudianteModel estudianteModel = db.EstudianteModels.Find(id);
            if (estudianteModel == null)
            {
                return HttpNotFound();
            }
            return View(estudianteModel);
        }

        // GET: Estudiante/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Estudiante/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,nombre")] EstudianteModel estudianteModel)
        {
            if (ModelState.IsValid)
            {
                db.EstudianteModels.Add(estudianteModel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(estudianteModel);
        }

        // GET: Estudiante/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstudianteModel estudianteModel = db.EstudianteModels.Find(id);
            if (estudianteModel == null)
            {
                return HttpNotFound();
            }
            return View(estudianteModel);
        }

        // POST: Estudiante/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,nombre")] EstudianteModel estudianteModel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(estudianteModel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(estudianteModel);
        }

        // GET: Estudiante/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstudianteModel estudianteModel = db.EstudianteModels.Find(id);
            if (estudianteModel == null)
            {
                return HttpNotFound();
            }
            return View(estudianteModel);
        }

        // POST: Estudiante/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EstudianteModel estudianteModel = db.EstudianteModels.Find(id);
            db.EstudianteModels.Remove(estudianteModel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
