﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ejercicio4.Data;
using Ejercicio4.Models;

namespace Ejercicio4.Controllers
{
    public class MateriaController : Controller
    {
        private Ejercicio4Context db = new Ejercicio4Context();

        // GET: Materia
        public ActionResult Index()
        {
            return View(db.MateriaModels.ToList());
        }

        // GET: Materia/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MateriaModel materiaModel = db.MateriaModels.Find(id);
            if (materiaModel == null)
            {
                return HttpNotFound();
            }
            return View(materiaModel);
        }

        // GET: Materia/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Materia/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,nombre")] MateriaModel materiaModel)
        {
            if (ModelState.IsValid)
            {
                db.MateriaModels.Add(materiaModel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(materiaModel);
        }

        // GET: Materia/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MateriaModel materiaModel = db.MateriaModels.Find(id);
            if (materiaModel == null)
            {
                return HttpNotFound();
            }
            return View(materiaModel);
        }

        // POST: Materia/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,nombre")] MateriaModel materiaModel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(materiaModel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(materiaModel);
        }

        // GET: Materia/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MateriaModel materiaModel = db.MateriaModels.Find(id);
            if (materiaModel == null)
            {
                return HttpNotFound();
            }
            return View(materiaModel);
        }

        // POST: Materia/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            MateriaModel materiaModel = db.MateriaModels.Find(id);
            db.MateriaModels.Remove(materiaModel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
