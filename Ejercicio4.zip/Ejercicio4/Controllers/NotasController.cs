﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ejercicio4.Data;
using Ejercicio4.Models;

namespace Ejercicio4.Controllers
{
    public class NotasController : Controller
    {
        private Ejercicio4Context db = new Ejercicio4Context();

        // GET: Notas
        public ActionResult Index()
        {
            var notasModels = db.NotasModels.Include(n => n.Estudiante).Include(n => n.Materia);
            return View(notasModels.ToList());
        }

        // GET: Notas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NotasModel notasModel = db.NotasModels.Find(id);
            if (notasModel == null)
            {
                return HttpNotFound();
            }
            return View(notasModel);
        }

        // GET: Notas/Create
        public ActionResult Create()
        {
            ViewBag.EstudianteId = new SelectList(db.EstudianteModels, "ID", "nombre");
            ViewBag.MateriaId = new SelectList(db.MateriaModels, "ID", "nombre");
            return View();
        }

        // POST: Notas/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,nota,periodo,EstudianteId,MateriaId")] NotasModel notasModel)
        {
            if (ModelState.IsValid)
            {
                db.NotasModels.Add(notasModel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EstudianteId = new SelectList(db.EstudianteModels, "ID", "nombre", notasModel.EstudianteId);
            ViewBag.MateriaId = new SelectList(db.MateriaModels, "ID", "nombre", notasModel.MateriaId);
            return View(notasModel);
        }

        // GET: Notas/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NotasModel notasModel = db.NotasModels.Find(id);
            if (notasModel == null)
            {
                return HttpNotFound();
            }
            ViewBag.EstudianteId = new SelectList(db.EstudianteModels, "ID", "nombre", notasModel.EstudianteId);
            ViewBag.MateriaId = new SelectList(db.MateriaModels, "ID", "nombre", notasModel.MateriaId);
            return View(notasModel);
        }

        // POST: Notas/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,nota,periodo,EstudianteId,MateriaId")] NotasModel notasModel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(notasModel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EstudianteId = new SelectList(db.EstudianteModels, "ID", "nombre", notasModel.EstudianteId);
            ViewBag.MateriaId = new SelectList(db.MateriaModels, "ID", "nombre", notasModel.MateriaId);
            return View(notasModel);
        }

        // GET: Notas/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NotasModel notasModel = db.NotasModels.Find(id);
            if (notasModel == null)
            {
                return HttpNotFound();
            }
            return View(notasModel);
        }

        // POST: Notas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            NotasModel notasModel = db.NotasModels.Find(id);
            db.NotasModels.Remove(notasModel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
