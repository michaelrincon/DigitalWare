﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class PruebaTecnica
    {
        static void Main(string[] args)
        {
            int[] myArray = new int[10] { 1, 2, 1, 3, 3, 1, 2, 1, 5, 1 };

            generarHistograma(myArray);

        }

        public static void generarHistograma(int [] numeros)
        {
            string[] histograma = new string[5] {"1:","2:","3:","4:","5:"};
            string asterisco = "*";
            for (int i=0;i<numeros.Length;i++)
            {
                histograma[numeros[i]-1] = histograma[numeros[i]-1] + asterisco;
            }

            foreach (var histo in histograma)
            {
                Console.WriteLine(histo);
            }
            Console.ReadLine();
        }
    }
}
